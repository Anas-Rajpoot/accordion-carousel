/* ============================================================
   HS Vertical Team Carousel — JavaScript
   window.hsInitTeamCarousel(config) — called by each widget instance
   Uses requestAnimationFrame for smooth, pauseable infinite scroll.
   ============================================================ */

(function (global) {
    'use strict';

    /**
     * Initialise one team carousel instance.
     * @param {object} cfg
     */
    function hsInitTeamCarousel(cfg) {
        var sectionEl  = document.getElementById(cfg.sectionId);
        var col1El     = document.getElementById(cfg.col1Id);
        var col2El     = cfg.col2Id ? document.getElementById(cfg.col2Id) : null;
        if (!sectionEl || !col1El) return;

        var track1 = col1El.querySelector('.hs-team-track');
        var track2 = col2El ? col2El.querySelector('.hs-team-track') : null;
        if (!track1) return;

        var speed1      = parseFloat(cfg.speed1) || 0.6;
        var speed2      = parseFloat(cfg.speed2) || 0.6;
        var pauseHover  = cfg.pauseOnHover !== false;
        var popupOn     = cfg.popup !== false;
        var popupAnim   = cfg.popupAnim || 'zoom';

        var paused  = false;
        var pos1    = 0;
        var pos2    = 0;
        var half1   = 0;
        var half2   = 0;
        var raf     = null;
        var activeCard = null;

        /* ── Duplicate items for seamless loop ── */
        function duplicateTrack(track) {
            var origCards = Array.prototype.slice.call(track.children);
            origCards.forEach(function (card) {
                var clone = card.cloneNode(true);
                clone.setAttribute('aria-hidden', 'true');
                track.appendChild(clone);
            });
        }

        duplicateTrack(track1);
        if (track2) duplicateTrack(track2);

        /* ── Measure half-heights after duplication ── */
        function measure() {
            var gap1 = parseFloat(getComputedStyle(track1).gap) || 0;
            var cards1 = Array.prototype.slice.call(track1.querySelectorAll('.hs-team-card'));
            var origCount1 = cards1.length / 2;
            var totalH1 = 0;
            for (var i = 0; i < origCount1; i++) {
                totalH1 += cards1[i].offsetHeight + gap1;
            }
            half1 = totalH1;

            if (track2) {
                var gap2   = parseFloat(getComputedStyle(track2).gap) || 0;
                var cards2 = Array.prototype.slice.call(track2.querySelectorAll('.hs-team-card'));
                var origCount2 = cards2.length / 2;
                var totalH2 = 0;
                for (var j = 0; j < origCount2; j++) {
                    totalH2 += cards2[j].offsetHeight + gap2;
                }
                half2 = totalH2;
                /* col2 starts scrolled so it moves downward from the beginning */
                pos2 = -half2;
            }
        }

        measure();

        /* ── RAF animation loop ── */
        function tick() {
            if (!paused && half1 > 0) {
                /* Col1: scroll UP */
                pos1 -= speed1;
                if (Math.abs(pos1) >= half1) pos1 = 0;
                track1.style.transform = 'translateY(' + pos1 + 'px)';

                /* Col2: scroll DOWN */
                if (track2 && half2 > 0) {
                    pos2 += speed2;
                    if (pos2 >= 0) pos2 = -half2;
                    track2.style.transform = 'translateY(' + pos2 + 'px)';
                }
            }
            raf = requestAnimationFrame(tick);
        }

        raf = requestAnimationFrame(tick);

        /* ── Remeasure on resize ── */
        var resizeTimer;
        window.addEventListener('resize', function () {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function () {
                pos1 = 0;
                pos2 = -half2;
                measure();
            }, 150);
        });

        /* ── Pause on section hover ── */
        if (pauseHover) {
            sectionEl.addEventListener('mouseenter', function () { paused = true; });
            sectionEl.addEventListener('mouseleave', function () {
                paused = false;
                if (activeCard) {
                    activeCard.classList.remove('hs-tc-active');
                    activeCard = null;
                }
            });
        }

        /* ── Popup ── */
        if (!popupOn) return;

        /* Create overlay once and append to body */
        var overlay = document.createElement('div');
        overlay.className   = 'hs-tc-overlay';
        overlay.setAttribute('data-anim', popupAnim);
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-label', 'Team member details');
        overlay.innerHTML =
            '<div class="hs-tc-modal">' +
                '<button class="hs-tc-close" aria-label="Close">' +
                    '<svg width="14" height="14" viewBox="0 0 14 14" fill="none">' +
                    '<path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>' +
                    '</svg>' +
                '</button>' +
                '<div class="hs-tc-modal-text">' +
                    '<p class="hs-tc-modal-name"></p>' +
                    '<p class="hs-tc-modal-position"></p>' +
                    '<p class="hs-tc-modal-desc"></p>' +
                '</div>' +
                '<div class="hs-tc-modal-img"><img src="" alt="" loading="lazy"></div>' +
            '</div>';

        document.body.appendChild(overlay);

        var modal    = overlay.querySelector('.hs-tc-modal');
        var closeBtn = overlay.querySelector('.hs-tc-close');
        var nameEl   = overlay.querySelector('.hs-tc-modal-name');
        var posEl    = overlay.querySelector('.hs-tc-modal-position');
        var descEl   = overlay.querySelector('.hs-tc-modal-desc');
        var imgEl    = overlay.querySelector('.hs-tc-modal-img img');

        /* Apply CSS variables from config to overlay */
        if (cfg.overlayBg)    overlay.style.setProperty('--hst-overlay-bg',   cfg.overlayBg);
        if (cfg.popupBg)      overlay.style.setProperty('--hst-popup-bg',     cfg.popupBg);
        if (cfg.popupWidth)   overlay.style.setProperty('--hst-popup-width',  cfg.popupWidth);

        function openPopup(card) {
            var name  = card.getAttribute('data-name')     || '';
            var pos   = card.getAttribute('data-position') || '';
            var desc  = card.getAttribute('data-desc')     || '';
            var img   = card.getAttribute('data-img')      || '';

            nameEl.textContent = name;
            posEl.textContent  = pos;
            descEl.textContent = desc;
            imgEl.src          = img;
            imgEl.alt          = name;

            if (activeCard) activeCard.classList.remove('hs-tc-active');
            activeCard = card;
            card.classList.add('hs-tc-active');

            overlay.classList.add('hs-tc-open');
            closeBtn.focus();
            paused = true;

            /* Trap focus */
            overlay.addEventListener('keydown', trapFocus);
        }

        function closePopup() {
            overlay.classList.remove('hs-tc-open');
            if (activeCard) {
                activeCard.classList.remove('hs-tc-active');
                activeCard = null;
            }
            paused = false;
            overlay.removeEventListener('keydown', trapFocus);
        }

        function trapFocus(e) {
            if (e.key === 'Escape') { closePopup(); return; }
            if (e.key !== 'Tab') return;
            var focusable = overlay.querySelectorAll(
                'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
            );
            var first = focusable[0];
            var last  = focusable[focusable.length - 1];
            if (e.shiftKey) {
                if (document.activeElement === first) { e.preventDefault(); last.focus(); }
            } else {
                if (document.activeElement === last)  { e.preventDefault(); first.focus(); }
            }
        }

        closeBtn.addEventListener('click', closePopup);

        /* Close on overlay click (outside modal) */
        overlay.addEventListener('click', function (e) {
            if (!modal.contains(e.target)) closePopup();
        });

        /* Attach card click/touch listeners */
        function attachCardListeners(track) {
            var cards = track.querySelectorAll('.hs-team-card:not([aria-hidden])');
            cards.forEach(function (card) {
                card.addEventListener('click', function () { openPopup(card); });
                card.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPopup(card); }
                });
                card.setAttribute('tabindex', '0');
                card.setAttribute('role', 'button');
            });
        }

        attachCardListeners(track1);
        if (track2) attachCardListeners(track2);
    }

    global.hsInitTeamCarousel = hsInitTeamCarousel;

}(window));
