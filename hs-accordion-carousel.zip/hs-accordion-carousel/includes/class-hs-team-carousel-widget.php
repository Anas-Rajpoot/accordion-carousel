<?php
/**
 * Elementor Widget: Vertical Team Carousel Pro
 * Part of the HS Accordion Carousel plugin.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class HS_Team_Carousel_Widget extends Widget_Base {

    public function get_name()  { return 'hs-team-carousel'; }
    public function get_title() { return esc_html__( 'Vertical Team Carousel Pro', 'hs-carousel' ); }
    public function get_icon()  { return 'eicon-person'; }
    public function get_categories() { return [ 'general' ]; }
    public function get_keywords()   { return [ 'team', 'carousel', 'vertical', 'scroll', 'members', 'popup' ]; }

    public function get_script_depends()  { return [ 'hs-team-carousel-js' ]; }
    public function get_style_depends()   { return [ 'hs-team-carousel-css' ]; }

    /* ──────────────────────────────────────────────────────
       CONTROLS
    ────────────────────────────────────────────────────── */
    protected function register_controls() {

        /* ══ CONTENT TAB ══ */

        /* ─ Section Heading ─ */
        $this->start_controls_section( 'section_heading', [
            'label' => esc_html__( 'Section Heading', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'heading', [
            'label'       => esc_html__( 'Heading', 'hs-carousel' ),
            'type'        => Controls_Manager::TEXTAREA,
            'default'     => esc_html__( "Working with great\nprofessionals in the market", 'hs-carousel' ),
            'placeholder' => esc_html__( 'Main heading text', 'hs-carousel' ),
            'rows'        => 3,
            'dynamic'     => [ 'active' => true ],
        ] );

        $this->add_control( 'heading_tag', [
            'label'   => esc_html__( 'Heading Tag', 'hs-carousel' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'h2',
            'options' => [ 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'p' => 'P' ],
        ] );

        $this->add_control( 'subheading', [
            'label'   => esc_html__( 'Subheading', 'hs-carousel' ),
            'type'    => Controls_Manager::TEXTAREA,
            'default' => esc_html__( 'With whom we have had very good personal and professional experiences.', 'hs-carousel' ),
            'rows'    => 3,
            'dynamic' => [ 'active' => true ],
        ] );

        $this->end_controls_section();

        /* ─ Team Members Repeater ─ */
        $this->start_controls_section( 'section_members', [
            'label' => esc_html__( 'Team Members', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $repeater = new Repeater();

        $repeater->add_control( 'member_image', [
            'label'   => esc_html__( 'Photo', 'hs-carousel' ),
            'type'    => Controls_Manager::MEDIA,
            'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            'dynamic' => [ 'active' => true ],
        ] );

        $repeater->add_control( 'member_name', [
            'label'       => esc_html__( 'Name', 'hs-carousel' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => esc_html__( 'Team Member', 'hs-carousel' ),
            'label_block' => true,
            'dynamic'     => [ 'active' => true ],
        ] );

        $repeater->add_control( 'member_position', [
            'label'       => esc_html__( 'Position / Company', 'hs-carousel' ),
            'type'        => Controls_Manager::TEXT,
            'default'     => esc_html__( 'Position · Company', 'hs-carousel' ),
            'label_block' => true,
            'dynamic'     => [ 'active' => true ],
        ] );

        $repeater->add_control( 'member_description', [
            'label'   => esc_html__( 'Description', 'hs-carousel' ),
            'type'    => Controls_Manager::TEXTAREA,
            'default' => esc_html__( 'A short description about this team member and their experience.', 'hs-carousel' ),
            'rows'    => 4,
            'dynamic' => [ 'active' => true ],
        ] );

        $this->add_control( 'members', [
            'label'       => esc_html__( 'Members', 'hs-carousel' ),
            'type'        => Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [ 'member_name' => 'Gemma Fornas',  'member_position' => 'CEO · Mutual Medica'       ],
                [ 'member_name' => 'Alex Rivera',   'member_position' => 'CTO · TechNova'            ],
                [ 'member_name' => 'Lucia Santos',  'member_position' => 'Design Lead · Pixel Studio' ],
                [ 'member_name' => 'Marco Fabbri',  'member_position' => 'Head of Sales · Nexus'     ],
                [ 'member_name' => 'Sara Kim',      'member_position' => 'Marketing · BrandBox'       ],
                [ 'member_name' => 'James Okafor',  'member_position' => 'Engineer · DeepCode'        ],
            ],
            'title_field' => '{{{ member_name }}}',
        ] );

        $this->end_controls_section();

        /* ─ Layout Controls ─ */
        $this->start_controls_section( 'section_layout', [
            'label' => esc_html__( 'Layout', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'columns', [
            'label'   => esc_html__( 'Columns', 'hs-carousel' ),
            'type'    => Controls_Manager::SELECT,
            'default' => '2',
            'options' => [ '1' => '1 Column', '2' => '2 Columns' ],
        ] );

        $this->add_control( 'section_height', [
            'label'      => esc_html__( 'Section / Columns Height', 'hs-carousel' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 200, 'max' => 900, 'step' => 10 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 520 ],
            'selectors'  => [ '{{WRAPPER}} .hs-team-columns' => 'height: {{SIZE}}{{UNIT}}; --hst-height: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'card_height', [
            'label'      => esc_html__( 'Card Height', 'hs-carousel' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 80, 'max' => 400, 'step' => 4 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 220 ],
            'selectors'  => [ '{{WRAPPER}} .hs-team-card' => 'height: {{SIZE}}{{UNIT}}; --hst-card-height: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'card_gap', [
            'label'      => esc_html__( 'Card Gap', 'hs-carousel' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 40, 'step' => 1 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 12 ],
            'selectors'  => [ '{{WRAPPER}} .hs-team-track' => 'gap: {{SIZE}}{{UNIT}}; --hst-card-gap: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'col_gap', [
            'label'      => esc_html__( 'Column Gap', 'hs-carousel' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 60, 'step' => 2 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 14 ],
            'selectors'  => [ '{{WRAPPER}} .hs-team-columns' => 'gap: {{SIZE}}{{UNIT}}; --hst-col-gap: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'border_radius', [
            'label'      => esc_html__( 'Card Border Radius', 'hs-carousel' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 0, 'max' => 32, 'step' => 1 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 16 ],
            'selectors'  => [ '{{WRAPPER}} .hs-team-card' => 'border-radius: {{SIZE}}{{UNIT}}; --hst-radius: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->add_control( 'show_lines', [
            'label'        => esc_html__( 'Background Lines', 'hs-carousel' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'hs-carousel' ),
            'label_off'    => esc_html__( 'Hide', 'hs-carousel' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'show_gradient', [
            'label'        => esc_html__( 'Left Gradient Overlay', 'hs-carousel' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'hs-carousel' ),
            'label_off'    => esc_html__( 'Hide', 'hs-carousel' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->end_controls_section();

        /* ─ Animation Controls ─ */
        $this->start_controls_section( 'section_animation', [
            'label' => esc_html__( 'Animation', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'speed_left', [
            'label'   => esc_html__( 'Left Column Speed (px/frame)', 'hs-carousel' ),
            'type'    => Controls_Manager::SLIDER,
            'range'   => [ 'px' => [ 'min' => 0.1, 'max' => 5, 'step' => 0.1 ] ],
            'default' => [ 'unit' => 'px', 'size' => 0.6 ],
        ] );

        $this->add_control( 'speed_right', [
            'label'     => esc_html__( 'Right Column Speed (px/frame)', 'hs-carousel' ),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [ 'px' => [ 'min' => 0.1, 'max' => 5, 'step' => 0.1 ] ],
            'default'   => [ 'unit' => 'px', 'size' => 0.6 ],
            'condition' => [ 'columns' => '2' ],
        ] );

        $this->add_control( 'pause_on_hover', [
            'label'        => esc_html__( 'Pause on Hover', 'hs-carousel' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'hs-carousel' ),
            'label_off'    => esc_html__( 'No', 'hs-carousel' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'hover_animation', [
            'label'   => esc_html__( 'Card Hover Effect', 'hs-carousel' ),
            'type'    => Controls_Manager::SELECT,
            'default' => 'scale',
            'options' => [
                'scale' => esc_html__( 'Scale', 'hs-carousel' ),
                'zoom'  => esc_html__( 'Zoom Image', 'hs-carousel' ),
                'fade'  => esc_html__( 'Brightness', 'hs-carousel' ),
            ],
        ] );

        $this->end_controls_section();

        /* ─ Popup Controls ─ */
        $this->start_controls_section( 'section_popup', [
            'label' => esc_html__( 'Popup', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'enable_popup', [
            'label'        => esc_html__( 'Enable Popup', 'hs-carousel' ),
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'hs-carousel' ),
            'label_off'    => esc_html__( 'No', 'hs-carousel' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'popup_animation', [
            'label'     => esc_html__( 'Popup Open Animation', 'hs-carousel' ),
            'type'      => Controls_Manager::SELECT,
            'default'   => 'zoom',
            'options'   => [
                'zoom'  => esc_html__( 'Zoom + Fade', 'hs-carousel' ),
                'slide' => esc_html__( 'Slide Up', 'hs-carousel' ),
            ],
            'condition' => [ 'enable_popup' => 'yes' ],
        ] );

        $this->add_control( 'popup_width', [
            'label'      => esc_html__( 'Popup Width', 'hs-carousel' ),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 400, 'max' => 900, 'step' => 10 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 680 ],
            'condition'  => [ 'enable_popup' => 'yes' ],
        ] );

        $this->add_control( 'overlay_color', [
            'label'     => esc_html__( 'Overlay Color', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(0,0,0,0.75)',
            'condition' => [ 'enable_popup' => 'yes' ],
        ] );

        $this->add_control( 'popup_bg', [
            'label'     => esc_html__( 'Popup Background', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(18,22,30,0.92)',
            'condition' => [ 'enable_popup' => 'yes' ],
        ] );

        $this->end_controls_section();

        /* ══ STYLE TAB ══ */

        /* ─ Section Background ─ */
        $this->start_controls_section( 'style_section', [
            'label' => esc_html__( 'Section', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control( Group_Control_Background::get_type(), [
            'name'     => 'section_bg',
            'label'    => esc_html__( 'Background', 'hs-carousel' ),
            'types'    => [ 'classic', 'gradient' ],
            'selector' => '{{WRAPPER}} .hs-team-section',
        ] );

        $this->add_responsive_control( 'section_padding', [
            'label'      => esc_html__( 'Padding', 'hs-carousel' ),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'selectors'  => [ '{{WRAPPER}} .hs-team-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ] );

        $this->add_control( 'accent_color', [
            'label'     => esc_html__( 'Accent Color (gradient / position)', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#00c8b4',
            'selectors' => [ '{{WRAPPER}} .hs-team-section' => '--hst-accent: {{VALUE}}; --hst-popup-pos-color: {{VALUE}};' ],
        ] );

        $this->add_control( 'gradient_color', [
            'label'     => esc_html__( 'Left Overlay Gradient Color', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(0,200,180,0.25)',
            'condition' => [ 'show_gradient' => 'yes' ],
            'selectors' => [
                '{{WRAPPER}} .hs-team-grad' => 'background: linear-gradient(135deg, {{VALUE}} 0%, transparent 70%);',
            ],
        ] );

        $this->add_control( 'font_family', [
            'label'     => esc_html__( 'Font Family', 'hs-carousel' ),
            'type'      => Controls_Manager::FONT,
            'default'   => 'Poppins',
            'selectors' => [ '{{WRAPPER}} .hs-team-section' => '--hst-font: "{{VALUE}}", sans-serif; font-family: "{{VALUE}}", sans-serif;' ],
        ] );

        $this->end_controls_section();

        /* ─ Heading Typography ─ */
        $this->start_controls_section( 'style_heading', [
            'label' => esc_html__( 'Heading', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'heading_color', [
            'label'     => esc_html__( 'Color', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [ '{{WRAPPER}} .hs-team-heading' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'heading_typo',
            'label'    => esc_html__( 'Typography', 'hs-carousel' ),
            'selector' => '{{WRAPPER}} .hs-team-heading',
        ] );

        $this->add_control( 'subheading_color', [
            'label'     => esc_html__( 'Subheading Color', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(255,255,255,0.6)',
            'selectors' => [ '{{WRAPPER}} .hs-team-subheading' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'subheading_typo',
            'label'    => esc_html__( 'Subheading Typography', 'hs-carousel' ),
            'selector' => '{{WRAPPER}} .hs-team-subheading',
        ] );

        $this->end_controls_section();

        /* ─ Cards Style ─ */
        $this->start_controls_section( 'style_cards', [
            'label' => esc_html__( 'Cards', 'hs-carousel' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control( Group_Control_Border::get_type(), [
            'name'     => 'card_border',
            'label'    => esc_html__( 'Border', 'hs-carousel' ),
            'selector' => '{{WRAPPER}} .hs-team-card',
        ] );

        $this->add_group_control( Group_Control_Box_Shadow::get_type(), [
            'name'     => 'card_shadow',
            'label'    => esc_html__( 'Box Shadow', 'hs-carousel' ),
            'selector' => '{{WRAPPER}} .hs-team-card',
        ] );

        $this->end_controls_section();

        /* ─ Popup Style ─ */
        $this->start_controls_section( 'style_popup', [
            'label'     => esc_html__( 'Popup', 'hs-carousel' ),
            'tab'       => Controls_Manager::TAB_STYLE,
            'condition' => [ 'enable_popup' => 'yes' ],
        ] );

        $this->add_control( 'popup_name_color', [
            'label'     => esc_html__( 'Name Color', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [ '{{WRAPPER}} .hs-tc-overlay .hs-tc-modal-name' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'popup_name_typo',
            'label'    => esc_html__( 'Name Typography', 'hs-carousel' ),
            'selector' => '{{WRAPPER}} .hs-tc-overlay .hs-tc-modal-name',
        ] );

        $this->add_control( 'popup_desc_color', [
            'label'     => esc_html__( 'Description Color', 'hs-carousel' ),
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(255,255,255,0.7)',
            'selectors' => [ '{{WRAPPER}} .hs-tc-overlay .hs-tc-modal-desc' => 'color: {{VALUE}};' ],
        ] );

        $this->add_group_control( Group_Control_Typography::get_type(), [
            'name'     => 'popup_desc_typo',
            'label'    => esc_html__( 'Description Typography', 'hs-carousel' ),
            'selector' => '{{WRAPPER}} .hs-tc-overlay .hs-tc-modal-desc',
        ] );

        $this->add_group_control( Group_Control_Box_Shadow::get_type(), [
            'name'     => 'popup_shadow',
            'label'    => esc_html__( 'Popup Box Shadow', 'hs-carousel' ),
            'selector' => '{{WRAPPER}} .hs-tc-overlay .hs-tc-modal',
        ] );

        $this->end_controls_section();
    }

    /* ──────────────────────────────────────────────────────
       RENDER
    ────────────────────────────────────────────────────── */
    protected function render() {
        $s      = $this->get_settings_for_display();
        $uid    = 'hstc-' . $this->get_id();
        $col1Id = $uid . '-c1';
        $col2Id = $uid . '-c2';
        $members = $s['members'] ?? [];

        if ( empty( $members ) ) return;

        /* Split members between columns */
        $mid      = (int) ceil( count( $members ) / 2 );
        $col1     = array_slice( $members, 0, $mid );
        $col2     = array_slice( $members, $mid );
        $twoCol   = $s['columns'] === '2' && ! empty( $col2 );

        /* Data attributes for JS */
        $data_attr = sprintf(
            'data-section-id="%s" data-col1="%s" data-col2="%s" data-speed1="%s" data-speed2="%s" data-pause="%s" data-popup="%s" data-popup-anim="%s" data-hover="%s" data-overlay="%s" data-popup-bg="%s" data-popup-width="%s"',
            esc_attr( $uid ),
            esc_attr( $col1Id ),
            $twoCol ? esc_attr( $col2Id ) : '',
            esc_attr( $s['speed_left']['size'] ?? 0.6 ),
            esc_attr( $s['speed_right']['size'] ?? 0.6 ),
            esc_attr( $s['pause_on_hover'] ?? 'yes' ),
            esc_attr( $s['enable_popup']   ?? 'yes' ),
            esc_attr( $s['popup_animation'] ?? 'zoom' ),
            esc_attr( $s['hover_animation'] ?? 'scale' ),
            esc_attr( $s['overlay_color']  ?? 'rgba(0,0,0,0.75)' ),
            esc_attr( $s['popup_bg']       ?? 'rgba(18,22,30,0.92)' ),
            esc_attr( ( $s['popup_width']['size'] ?? 680 ) . ( $s['popup_width']['unit'] ?? 'px' ) )
        );
        ?>

        <div class="hs-team-section hs-team-widget"
             id="<?php echo esc_attr( $uid ); ?>"
             data-hover="<?php echo esc_attr( $s['hover_animation'] ?? 'scale' ); ?>"
             <?php echo $data_attr; ?>>

            <?php if ( 'yes' === ( $s['show_lines'] ?? 'yes' ) ) : ?>
            <div class="hs-team-lines" aria-hidden="true">
                <?php for ( $i = 0; $i < 14; $i++ ) : ?>
                    <div class="hs-team-line"></div>
                <?php endfor; ?>
            </div>
            <?php endif; ?>

            <?php if ( 'yes' === ( $s['show_gradient'] ?? 'yes' ) ) : ?>
            <div class="hs-team-grad" aria-hidden="true"></div>
            <?php endif; ?>

            <div class="hs-team-inner">

                <!-- Left text content -->
                <div class="hs-team-content">
                    <?php if ( ! empty( $s['heading'] ) ) :
                        $tag = esc_attr( $s['heading_tag'] ?? 'h2' );
                        echo '<' . $tag . ' class="hs-team-heading">' . wp_kses_post( nl2br( $s['heading'] ) ) . '</' . $tag . '>';
                    endif; ?>
                    <?php if ( ! empty( $s['subheading'] ) ) : ?>
                        <p class="hs-team-subheading"><?php echo wp_kses_post( $s['subheading'] ); ?></p>
                    <?php endif; ?>
                </div>

                <!-- Columns -->
                <div class="hs-team-columns">

                    <!-- Column 1 (scrolls UP) -->
                    <div class="hs-team-col" id="<?php echo esc_attr( $col1Id ); ?>">
                        <div class="hs-team-track">
                            <?php foreach ( $col1 as $member ) :
                                $img_url = $member['member_image']['url'] ?? '';
                                $img_alt = $member['member_name'] ?? '';
                                ?>
                                <div class="hs-team-card"
                                     data-name="<?php echo esc_attr( $member['member_name']        ?? '' ); ?>"
                                     data-position="<?php echo esc_attr( $member['member_position']   ?? '' ); ?>"
                                     data-desc="<?php echo esc_attr( $member['member_description'] ?? '' ); ?>"
                                     data-img="<?php echo esc_url( $img_url ); ?>"
                                     tabindex="0" role="button"
                                     aria-label="<?php echo esc_attr( $img_alt ); ?>">
                                    <?php if ( $img_url ) : ?>
                                        <img src="<?php echo esc_url( $img_url ); ?>"
                                             alt="<?php echo esc_attr( $img_alt ); ?>"
                                             loading="lazy">
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Column 2 (scrolls DOWN) — only if 2-col mode -->
                    <?php if ( $twoCol ) : ?>
                    <div class="hs-team-col" id="<?php echo esc_attr( $col2Id ); ?>">
                        <div class="hs-team-track">
                            <?php foreach ( $col2 as $member ) :
                                $img_url = $member['member_image']['url'] ?? '';
                                $img_alt = $member['member_name'] ?? '';
                                ?>
                                <div class="hs-team-card"
                                     data-name="<?php echo esc_attr( $member['member_name']        ?? '' ); ?>"
                                     data-position="<?php echo esc_attr( $member['member_position']   ?? '' ); ?>"
                                     data-desc="<?php echo esc_attr( $member['member_description'] ?? '' ); ?>"
                                     data-img="<?php echo esc_url( $img_url ); ?>"
                                     tabindex="0" role="button"
                                     aria-label="<?php echo esc_attr( $img_alt ); ?>">
                                    <?php if ( $img_url ) : ?>
                                        <img src="<?php echo esc_url( $img_url ); ?>"
                                             alt="<?php echo esc_attr( $img_alt ); ?>"
                                             loading="lazy">
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                </div><!-- .hs-team-columns -->
            </div><!-- .hs-team-inner -->
        </div><!-- .hs-team-section -->

        <script>
        (function(){
            function init() {
                var el = document.getElementById('<?php echo esc_js( $uid ); ?>');
                if (!el || !window.hsInitTeamCarousel) return;
                hsInitTeamCarousel({
                    sectionId:   '<?php echo esc_js( $uid ); ?>',
                    col1Id:      '<?php echo esc_js( $col1Id ); ?>',
                    col2Id:      <?php echo $twoCol ? '"' . esc_js( $col2Id ) . '"' : 'null'; ?>,
                    speed1:      <?php echo (float) ( $s['speed_left']['size']  ?? 0.6 ); ?>,
                    speed2:      <?php echo (float) ( $s['speed_right']['size'] ?? 0.6 ); ?>,
                    pauseOnHover:<?php echo 'yes' === ( $s['pause_on_hover'] ?? 'yes' ) ? 'true' : 'false'; ?>,
                    popup:       <?php echo 'yes' === ( $s['enable_popup']   ?? 'yes' ) ? 'true' : 'false'; ?>,
                    popupAnim:   '<?php echo esc_js( $s['popup_animation'] ?? 'zoom' ); ?>',
                    overlayBg:   '<?php echo esc_js( $s['overlay_color']   ?? '' ); ?>',
                    popupBg:     '<?php echo esc_js( $s['popup_bg']        ?? '' ); ?>',
                    popupWidth:  '<?php echo esc_js( ( $s['popup_width']['size'] ?? 680 ) . ( $s['popup_width']['unit'] ?? 'px' ) ); ?>',
                });
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', init);
            } else {
                init();
            }
        })();
        </script>
        <?php
    }
}
